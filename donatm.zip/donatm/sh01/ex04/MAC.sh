ifconfig | grep -o ..:..:..:..:..:..
