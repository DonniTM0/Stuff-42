/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dmisini <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/12 12:52:50 by dmisini           #+#    #+#             */
/*   Updated: 2023/07/12 16:32:25 by dmisini          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}
/*
int	main(void)
{
	int	n;
	int	*pn1;
	int	**pn2;
	int	***pn3;
	int	****pn4;
	int	*****pn5;
	int	******pn6;
	int	*******pn7;
	int	********pn8;
	int	*********pn9;
	
	pn9 = &pn8;
	pn8 = &pn7;
	pn7 = &pn6;
	pn6 = &pn5;
	pn5 = &pn4;
	pn4 = &pn3;
	pn3 = &pn2;
	pn2 = &pn1;
	pn1 = &n;
	
	n = 24;
	printf("Before: %d\n", n);
	ft_ultimate_ft(pn9);
	printf("After: %d\n", n);
}
*/
